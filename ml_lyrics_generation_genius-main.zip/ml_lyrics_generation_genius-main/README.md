# Library to automatically generate a dataset of artist lyrics from the genius api and generate new songs based on these lyrics using the nlp n-gram model

брошен вместо лязга

я ставлю на шее петлю

она знает мне страшно

к нему несемся

а ждать, да слышен стук зубов
